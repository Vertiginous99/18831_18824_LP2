﻿using System;

using Interact;

namespace TPLP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Controller.Start();
        }
    }
}
