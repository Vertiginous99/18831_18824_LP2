﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Exepcoes;
using ObjetosNegocio;

namespace Dados
{
    [Serializable]
    public class Hospital
    {
        #region Estado

        const int MAXPESSOA = 50;
        static int numDoente = 0;
        private static List<Doentes> doentes;

        #endregion

        #region Construtores

        static Hospital()
        {
            doentes = new List<Doentes>();
        }

        #endregion

        #region Propriedades

        public static List<Doentes> DoentesList
        {
            get { return doentes; }
        }

        #endregion

        #region Metodos

        /// <summary>
        /// Regista um doente
        /// </summary>
        /// <param Doentes="d">Ficha do Doente</param>
        public static bool InsereDoente(Doentes d)
        {
            try
            {
                doentes.Add(d);
                numDoente++;
                d.Id = numDoente;

                return true;
            }catch (InsereException e)
            {
                throw new InsereException("Erro no registo do doente!");
            }

            return false;
        }

        /// <summary>
        /// Regista uma infecao num doente
        /// </summary>
        /// <param Doentes="d">Ficha do Doente</param>
        /// <param Infecao="infec">Informcao sobre a infecao</param>
        public static bool RegistaInfecao(Infecao infec, Doentes d)
        {
            try
            {
                d.AddInfecao = infec;

                return true;
            } catch (InsereException e)
            {
                throw new InsereException("Erro no registo da infecao!");
            }

            return false;
        }

        #endregion

        #region saves

        public static bool SaveDados(string fileName)
        {
            Stream stream = File.Open(fileName, FileMode.Create);
            BinaryFormatter bin = new BinaryFormatter();
            bin.Serialize(stream, doentes);
            stream.Close();
            return true;
        }

        public static bool LoadDados(string fileName)
        {
            if (File.Exists(fileName))
            {
                try
                {
                    Stream stream = File.Open(fileName, FileMode.Open);
                    BinaryFormatter bin = new BinaryFormatter();
                    doentes = (List<Doentes>)bin.Deserialize(stream);
                    stream.Close();
                    return true;
                }
                catch (IOException e)
                {
                    throw e;
                }
            }

            return false;
        }

        public static void ClearDoentes()
        {
            doentes.Clear();
        }

        #endregion
    }
}
