﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ObjetosNegocio
{
    [Serializable]
    public class Doentes : Pessoa
    {
        #region Estado

        Infecao inf;
        bool ativo;

        #endregion

        #region Construtor

        /// <summary>
        /// Construtor da classe Doentes
        /// </summary>
        /// <param Infecao="inf">Ficha da infecao</param>
        public Doentes(Infecao inf)
        {
            this.inf = inf;
            this.ativo = true;
        }

        /// <summary>
        /// Construtor da classe Doentes
        /// </summary>
        /// <param Infecao="inf">Ficha da infecao</param>
        /// <param int="idade">Idade do doente</param>
        /// <param string="nome">Nome do doente</param>
        /// <param int="regiao">Região do doente</param>
        /// <param DateTime="dataNasc">Data de nascimento do doente</param>
        /// <param int="sexo">Sexo do doente</param>
        /// <param int="profissao">Profissao do doente</param>
        public Doentes(Infecao inf, int idade, string nome, int regiao, DateTime dataNasc, int sexo, int profissao)
                        : base(idade, nome, regiao, dataNasc, sexo, profissao)
        {
            this.inf = inf;
            this.ativo = true;
        }

        #endregion

        #region Propriedades

        public Infecao AddInfecao
        {
            get { return inf; }
            set { inf = value; }
        }

        public bool Ativo
        {
            get { return ativo; }
            set { ativo = value; }
        }

        #endregion
    }
}
