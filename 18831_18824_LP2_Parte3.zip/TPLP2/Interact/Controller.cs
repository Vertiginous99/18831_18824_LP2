﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Dados;
using ObjetosNegocio;
using RegrasNegocio;

namespace Interact
{
    public class Controller
    {
        public static void Start()
        {
            // Caminho da base de dados do ficheiro
            string fileName = @"C:\Temp\doentes.bin";

            // Obter os dados do ficheiro
            Hospital.LoadDados(fileName);

            // Ativar o menu
            Regra.ObterProcesso();
        }
    }
}
