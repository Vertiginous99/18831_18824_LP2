﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public abstract class Pessoa
    {
        #region Enums

        public enum Region
        {
            Norte = 0,
            Sul = 1,
            Centro = 2
        }

        public enum Sexo
        {
            Masculino = 0,
            Feminino,
            Outro
        }

        public enum Profissao
        {
            PROFESSOR = 0,
            FUNCIONARIO,
            ALUNO,
            DESEMPREGADO,
            OUTRO
        }

        #endregion

        #region Estado

        int idade;
        string nome;
        Region regiao;
        int id;
        Sexo sexo;
        DateTime dataNasc;
        Profissao prof;

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor para os dados em omissão
        /// </summary>
        public Pessoa()
        {
            idade = 0;
            nome = "";
            prof = Profissao.DESEMPREGADO;
        }

        /// <summary>
        /// Construtor para os dados vindos do exterior
        /// </summary>
        /// <param name="i">Idade</param>
        /// <param name="n">Nome</param>
        /// <param name="m">Morada</param>
        /// <param name="date">Data</param>
        public Pessoa(int i, string n, int d, DateTime date, int sexo, int profissao)
        {
            idade = i;
            nome = n;
            regiao = (Region)d;
            dataNasc = date;
            this.sexo = (Sexo)sexo;
            this.prof = (Profissao)profissao;
        }

        #endregion

        #region Propriedades

        public Sexo Sex
        {
            get { return sexo; }
            set { sexo = value; }
        }

        public Profissao Profi
        {
            get { return prof; }
            set { prof = value; }
        }

        public int Idade
        {
            get { return idade; }
            set { if (value > 0) idade = value; }
        }

        public int Id
        {
            get { return id; }
            set { if (value > 0) id = value; }
        }

        public string Nome
        {
            get { return nome; }
        }

        public Region Regiao
        {
            get { return regiao; }
        }

        public DateTime DataNasc
        {
            get { return dataNasc; }
            set
            {
                DateTime aux;
                if (DateTime.TryParse(value.ToString(), out aux) == true)
                {
                    dataNasc = value;
                }
            }
        }

        #endregion
    }
}
