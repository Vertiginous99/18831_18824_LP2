﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dados;
using Exepcoes;
using ObjetosNegocio;

namespace RegrasNegocio
{
    public class Regra
    {
        private static bool AdicionaInfec(Infecao i, Doentes d)
        {
            if (Hospital.DoentesList.Contains(d) == true) return Hospital.RegistaInfecao(i, d);

            return false;
        }

        private static bool InsereHos(Doentes d)
        {
            if (Hospital.DoentesList.Contains(d) == false)
                return Hospital.InsereDoente(d);

            return false;
        }

        #region MetodosAux
        /// <summary>
        /// Procura a ficha de determinada pessoa
        /// </summary>
        /// <param int="id">ID do Doente</param>
        /// <returns>Ficha da Pessoa</returns>
        private static void GetDoente(int id)
        {
            int prog = 0;

            foreach (Doentes i in Hospital.DoentesList) { 
                if (i.Id == id) {
                    ShowFicha(id);
                    prog = 1;
                    break;
                } else if(prog == 0)
                    Console.WriteLine($"Doente com id {id} nao se encontra no hospital!");
            }       
        }

        /// <summary>
        /// Verifica se uma pessoa existe pelo nome
        /// </summary>
        /// <param string="nome">Nome do Doente</param>
        /// <returns>Retorna a ficha do doente com o nome dado ou null caso não exista</returns>
        public static void WhereIsNome(string nome)
        {
            int prog = 0;

            foreach (Doentes i in Hospital.DoentesList)
                if (nome.Equals(i.Nome)) {
                    ShowFicha(i.Id);
                    prog = 1;
                }
                else if (prog == 0)
                    Console.WriteLine($"Doente com nome {nome} nao se encontra no hospital!");
        }

        /// <summary>
        /// Conta o numero de casos ativos
        /// </summary>
        /// <returns>Retorna o numero de casos positivos</returns>
        private static int ContaCasos()
        {
            int count = 0;

            foreach (Doentes i in Hospital.DoentesList)
                if (i.Ativo == true) count++;

            return count;
        }

        private static int ContaRegiao(int key)
        {
            int count = 0;

            foreach (Doentes i in Hospital.DoentesList)
                if (i.Ativo == true && (int)i.Regiao == key) count++;

            return count;
        }

        /// <summary>
        /// Conta casos na regiao
        /// </summary>
        /// <returns>Retorna o numero de casos positivos na regiao</returns>
        private static void ConsultarRegiao()
        {
            int countA = ContaRegiao(0);
            int countB = ContaRegiao(1);
            int countC = ContaRegiao(2);

            Console.WriteLine("Norte            -> " + countA + " casos!");
            Console.WriteLine("Centro           -> " + countB + " casos!");
            Console.WriteLine("Sul              -> " + countC + " casos!");
            Console.WriteLine();
        }

        private static int ContaIdade(int key)
        {
            int count = 0;

            foreach(Doentes i in Hospital.DoentesList)
                if(i.Idade == key) count++;
            
            return count;
        }

        /// <summary>
        /// Conta o numero de casos com determinada idade
        /// </summary>
        /// <param int="age">I</param>
        /// <returns>Retorna o numero de casos com determinada idade</returns>
        private static void ConsultarIdade(int age)
        {
            int count = ContaIdade(age);

            Console.WriteLine("Com idade " + age + " existem " + count + " casos!");
            Console.WriteLine();
        }

        private static int ContaProfissao(int key)
        {
            int count = 0;

            foreach (Doentes i in Hospital.DoentesList)
                if (i.Ativo == true && (int)i.Profi == key) count++;

            return count;
        }

        /// <summary>
        /// Verifica qual e imprime o numero de casos nas varias profissoes
        /// </summary>
        private static void ConsultarProfissao()
        {
            int countA = ContaProfissao(0);
            int countB = ContaProfissao(1);
            int countC = ContaProfissao(2);
            int countD = ContaProfissao(3);
            int countE = ContaProfissao(4);

            Console.WriteLine("Professores      -> " + countA + " casos!");
            Console.WriteLine("Funcionarios     -> " + countB + " casos!");
            Console.WriteLine("Alunos           -> " + countC + " casos!");
            Console.WriteLine("Desempregado     -> " + countD + " casos!");
            Console.WriteLine("Outro            -> " + countE + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Desativa um infetado (fica curado)
        /// </summary>
        /// <param int="id">ID do doente</param>
        private static void DesativarInfetado(int id)
        {
            foreach (Doentes i in Hospital.DoentesList)
                if (i.Id == id)
                {
                    Hospital.DoentesList[id - 1].Ativo = false;
                    Console.WriteLine($"Id {id} desativado com sucesso!");
                }
                else
                    Console.WriteLine($"Doente com id {id} nao se encontra no hospital!");  
        }

        private static int ContaSexo(int key)
        {
            int count = 0;

            foreach(Doentes i in Hospital.DoentesList)
                if((int)i.Sex == key) count++;
            
            return count;
        }

        /// <summary>
        /// Imprime o numero de infetados de determinado sexo
        /// </summary>
        private static void ConsultarSexo()
        {
            int countA = 0;
            int countB = 0;
            int countC = 0;

            foreach (Doentes i in Hospital.DoentesList)
            {
                if (i.Ativo == true && (int)i.Sex == 0) countA++;

                if (i.Ativo == true && (int)i.Sex == 1) countB++;

                if (i.Ativo == true && (int)i.Sex == 2) countC++;
            }

            Console.WriteLine("Masculino        -> " + countA + " casos!");
            Console.WriteLine("Feminino         -> " + countB + " casos!");
            Console.WriteLine("Outro            -> " + countC + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Procedimento que mostra a ficha de um determinado infetado através do id vindo do exterior
        /// </summary>
        /// <param int="i">Id</param>
        private static void ShowFicha(int id)
        {
            Console.WriteLine("Ficha do id " + id + " ...");
            Console.WriteLine("Doente           : " + Hospital.DoentesList[id - 1].Nome);
            Console.WriteLine("Idade            : " + Hospital.DoentesList[id - 1].Idade);
            Console.WriteLine("ID               : " + Hospital.DoentesList[id - 1].Id);
            Console.WriteLine("Região           : " + Hospital.DoentesList[id - 1].Regiao);
            Console.WriteLine("Nasceu em        : " + Hospital.DoentesList[id - 1].DataNasc);
            Console.WriteLine("Sexo             : " + Hospital.DoentesList[id - 1].Sex);
            Console.WriteLine("Estado Civil     : " + Hospital.DoentesList[id - 1].Profi);
            Console.WriteLine("Infetado com     : " + Hospital.DoentesList[id - 1].AddInfecao.Tipo + " concretamente " + Hospital.DoentesList[id - 1].AddInfecao.Nome);
            Console.WriteLine("Ainda infetado   : " + Hospital.DoentesList[id - 1].Ativo);
            Console.WriteLine();
        }

        private static void ShowAll()
        {
            foreach(Doentes i in Hospital.DoentesList)
            {
                Console.WriteLine("Doente           : " + i.Nome);
                Console.WriteLine("Idade            : " + i.Idade);
                Console.WriteLine("ID               : " + i.Id);
                Console.WriteLine("Região           : " + i.Regiao);
                Console.WriteLine("Nasceu em        : " + i.DataNasc);
                Console.WriteLine("Sexo             : " + i.Sex);
                Console.WriteLine("Estado Civil     : " + i.Profi);
                Console.WriteLine("Infetado com     : " + i.AddInfecao.Tipo + " concretamente " + i.AddInfecao.Nome);
                Console.WriteLine("Ainda infetado   : " + i.Ativo);
                Console.WriteLine();
            }

            Console.WriteLine("Casos Infetados: " + ContaCasos());
            Console.WriteLine();
        }

        private static Infecao ObterInfecao()
        {
            string infecao1 = "Virus";
            string infecao2 = "HIV";

            Console.WriteLine("Dados da doenca:");

            try
            {
                Console.Write("Digite o tipo de infecao: ");
                infecao1 = Console.ReadLine();
                Console.Write("Digite o nome da infecao: ");
                infecao2 = Console.ReadLine();

                Console.WriteLine();
            } catch(InsereException e)
            {
                InsereException erro = new InsereException("Erro na leitura dos dados!", e);
            } catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            

            Infecao inf = new Infecao(infecao1, infecao2);

            return inf;
        }

        private static Doentes ObterDoente(Infecao inf)
        {
            int idade = 18;
            string nome = "Default";
            int regiao = 0;
            int sexo = 0;
            int prof = 0;

            Console.WriteLine("Dados do doente:");

            try
            {
                Console.Write("Digite a idade: ");
                idade = Convert.ToInt32(Console.ReadLine());
                Console.Write("Digite o nome: ");
                nome = Console.ReadLine();
                Console.Write("Digite a regiao (0/1/2): ");
                regiao = Convert.ToInt32(Console.ReadLine());
                Console.Write("Digite o sexo (0/1/2): ");
                sexo = Convert.ToInt32(Console.ReadLine());
                Console.Write("Digite a profissao (0/1/2/3/4): ");
                prof = Convert.ToInt32(Console.ReadLine());

                Console.Clear();
            } catch(InsereException e)
            {
                InsereException erro = new InsereException("Erro na leitura dos dados!", e);
            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Doentes doentes = new Doentes(inf, idade, nome, regiao, DateTime.Today, sexo, prof);

            return doentes;
        }

        private static Doentes ObterDados()
        {
            Infecao inf = ObterInfecao();
            Doentes d = ObterDoente(inf);

            return d;
        }

        private static bool InserirDoente(Doentes d)
        {
            bool aux;

            try
            {
                aux = Regra.InsereHos(d);

                return aux;
            } catch(InsereException e)
            {
                InsereException erro = new InsereException("Erro na gravacao dos dados!", e);
            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return false;
        }

        private static void AuxProcesso()
        {
            Doentes doentes;
            bool processo = false;

            try
            {
                doentes = ObterDados();
                processo = InserirDoente(doentes);
            } catch(InsereException e)
            {
                InsereException erro = new InsereException("Erro na obtencao dos dados!", e);
            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            if (processo == true)
                Console.WriteLine("Pessoa inserida com sucesso!");
            else
                Console.WriteLine("Pessoa nao inserida!");

            Console.WriteLine();
        }

        private static void ComecaProcesso()
        {
            int progresso = 1;

            while (progresso == 1)
            {
                try
                {
                    AuxProcesso();
                    Console.Write("Digite (1 - continuar/ 0 - sair): ");
                    progresso = Convert.ToInt32(Console.ReadLine());
                } catch(InsereException e)
                {
                    InsereException erro = new InsereException("Erro na obtencao dos dados!", e);
                } catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        private static void Executa(int prog)
        {
            switch (prog)
            {
                case 1:
                    string fileName = @"C:\Temp\doentes.bin";
                    // Guardar os dados
                    Hospital.SaveDados(fileName);

                    // Apagar a lista antes de abandonar o programa
                    Hospital.ClearDoentes();
                    System.Environment.Exit(1);

                    break;

                case 2:
                    try
                    {
                        Console.Write("Insere id: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        GetDoente(id);
                        Console.ReadKey();
                        ObterProcesso();
                    } catch(InsereException e)
                    {
                        InsereException erro = new InsereException("Erro na obtencao do id!", e);
                    } catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    } finally
                    {
                        ObterProcesso();
                    }

                    break;

                case 3:
                    try
                    {
                        Console.Write("Insere nome: ");
                        string nome = Console.ReadLine();
                        WhereIsNome(nome);
                        Console.ReadKey();
                        ObterProcesso();
                    }
                    catch (InsereException e)
                    {
                        InsereException erro = new InsereException("Erro na obtencao do nome!", e);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    } finally
                    {
                        ObterProcesso();
                    }

                    break;

                case 4:
                    ComecaProcesso();
                    Console.ReadKey();
                    ObterProcesso();

                    break;

                case 5:
                    ConsultarRegiao();
                    Console.ReadKey();
                    ObterProcesso();

                    break;

                case 6:
                    try
                    {
                        Console.Write("Insere idade: ");
                        int idade = Convert.ToInt32(Console.ReadLine());
                        ConsultarIdade(idade);
                        Console.ReadKey();
                        ObterProcesso();
                    }
                    catch (InsereException e)
                    {
                        InsereException erro = new InsereException("Erro na obtencao do id!", e);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    } finally
                    {
                        ObterProcesso();
                    }

                    break;

                case 7:
                    ConsultarProfissao();
                    Console.ReadKey();
                    ObterProcesso();

                    break;

                case 8:
                    ConsultarSexo();
                    Console.ReadKey();
                    ObterProcesso();

                    break;

                case 9:
                    try
                    {
                        Console.Write("Insere id: ");
                        int id = Convert.ToInt32(Console.ReadLine());
                        DesativarInfetado(id);
                        Console.ReadKey();
                        ObterProcesso();
                    }
                    catch (InsereException e)
                    {
                        InsereException erro = new InsereException("Erro na obtencao do id!", e);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e.Message);
                    } finally
                    {
                        ObterProcesso();
                    }

                    break;

                case 10:
                    ShowAll();
                    Console.ReadKey();
                    ObterProcesso();

                    break;

                default:
                    Console.ReadKey();
                    ObterProcesso();
                    break;
            }
        }

        public static void ObterProcesso() {
            int progresso = 1;

            Console.WriteLine("Digite...");
            Console.WriteLine("1 - Sair");
            Console.WriteLine("2 - Obter ficha da pessoa por id");
            Console.WriteLine("3 - Obter ficha da pessoa por nome");
            Console.WriteLine("4 - Adicionar doente");
            Console.WriteLine("5 - Consultar por regiao");
            Console.WriteLine("6 - Consultar por idade");
            Console.WriteLine("7 - Consultar por profissao");
            Console.WriteLine("8 - Consultar por sexo");
            Console.WriteLine("9 - Desativar doente");
            Console.WriteLine("10 - Mostrar todos os doentes");

            try
            {
                progresso = Convert.ToInt32(Console.ReadLine());
            } catch(InsereException e)
            {
                InsereException erro = new InsereException("Erro na obtencao da resposa!", e);
            } catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            Executa(progresso);
        }

        #endregion
    }
}
