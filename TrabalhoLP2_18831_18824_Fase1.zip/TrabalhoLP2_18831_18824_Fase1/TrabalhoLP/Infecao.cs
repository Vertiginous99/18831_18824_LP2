﻿using System;
namespace TrabalhoLP
{
    public class Infecao
    {

        #region Estado

        // Pode ser um virus, uma bacteria, etc. É o tipo de infeção/doença apresentada
        string tipo;
        // Nome da doença
        string nome;

        // Um exemplo de tipo e nome pode ser:
        // tipo - Virus
        // nome - Covid-19

        #endregion

        #region Construtor

        public Infecao(string t, string n)
        {
            tipo = t;
            nome = n;
        }

        #endregion

        #region Properties

        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public string Nome
        {
            get { return nome; }
            set { nome = value; }
        }

        #endregion

    }
}
