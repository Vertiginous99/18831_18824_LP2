﻿using System;
namespace TrabalhoLP
{
    public class Hospital
    {
        #region Estado

        const int MAXPESSOA = 50;
        static int numDoente;
        static Doentes[] doentes;

        #endregion

        #region Construtores

        /// <summary>
        /// Construtor da classe Hospital
        /// </summary>
        /// <param></param>
        /// <returns></returns>
        public Hospital()
        {
            doentes = new Doentes[MAXPESSOA];
            numDoente = 0;
        }

        #endregion

        #region Metodos
        
        /// <summary>
        /// Regista um doente
        /// </summary>
        /// <param Doentes="d">Ficha do Doente</param>
        public int InsereDoente(Doentes d)
        {
            if (numDoente >= MAXPESSOA) return 0;

            doentes[numDoente] = d;
            numDoente++;
            d.Id = numDoente;

            return 1;
        }

        /// <summary>
        /// Regista uma infecao num doente
        /// </summary>
        /// <param Doentes="d">Ficha do Doente</param>
        /// <param Infecao="infec">Informcao sobre a infecao</param>
        public static void RegistaInfecao(Infecao infec, Doentes d)
        {
            d.AddInfecao = infec;
        }

        #endregion

        #region MetodosAux

        /// <summary>
        /// Verifica se existe uma determinado doente pelo seu nome
        /// </summary>
        /// <param string="nome">Nome do Doente</param>
        /// <returns>True caso exista o nome, Falso caso contrario</returns>
        public bool ExisteDoenteNome(string nome)
        {
            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i].Nome.CompareTo(nome) == 0)
                {
                    return true;
                }
            }
            return false;
        }

        /// <summary>
        /// Verifica se existe uma determinado doente pelo seu ID
        /// </summary>
        /// <param Doentes="d">Doente</param>
        /// <returns>True caso exista o id, Falso caso contrario</returns>
        public bool ExisteDoenteID(Doentes d)
        {
            int id = d.Id;

            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i].Id == id)
                {
                    return true;
                }
            }
            return false;
        }


        /// <summary>
        /// Procura a ficha de determinada pessoa
        /// </summary>
        /// <param int="id">ID do Doente</param>
        /// <returns>Ficha da Pessoa</returns>
        public static Pessoa GetDoente(int id)
        {
            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i] != null && doentes[i].Id == id) return doentes[i];
            }
            return null;
        }

        /// <summary>
        /// Verifica se uma pessoa existe pelo nome
        /// </summary>
        /// <param string="nome">Nome do Doente</param>
        /// <returns>Retorna a ficha do doente com o nome dado ou null caso não exista</returns>
        public static Pessoa WhereIsNome(string nome)
        {
            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i] != null && doentes[i].Nome.CompareTo(nome) == 0)
                {
                    return doentes[i];
                }
            }
            return null;
        }

        /// <summary>
        /// Verifica se uma pessoa existe pelo seu ID
        /// </summary>
        /// <param int="id">ID do Doente</param>
        /// <returns>Retorna a ficha do doente com o id dado ou null caso não exista</returns>
        public static Pessoa WhereIsID(int id)
        {
            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i] != null && doentes[i].Id == id)
                {
                    return doentes[i];
                }
            }
            return null;
        }
        
        /// <summary>
        /// Conta o numero de casos ativos
        /// </summary>
        /// <returns>Retorna o numero de casos positivos</returns>
        public static int ContaCasos(){
            int count = 0;
            for(int i = 0; i < numDoente; i++){
                if(doentes[i].Ativo == true)
                    count++;
            }
            return count;
        }
        
        /// <summary>
        /// Conta casos na regiao
        /// </summary>
        /// <returns>Retorna o numero de casos positivos na regiao</returns>
        public void ConsultarRegiao()
        {
            int countA = 0;
            int countB = 0;
            int countC = 0;

            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i].Ativo == true && (int)doentes[i].Regiao == 0)
                    countA++;

                if (doentes[i].Ativo == true && (int)doentes[i].Regiao == 1)
                    countB++;

                if (doentes[i].Ativo == true && (int)doentes[i].Regiao == 2)
                    countC++;
            }

            Console.WriteLine("Norte            -> " + countA + " casos!");
            Console.WriteLine("Centro           -> " + countB + " casos!");
            Console.WriteLine("Sul              -> " + countC + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Conta o numero de casos com determinada idade
        /// </summary>
        /// <param int="age">I</param>
        /// <returns>Retorna o numero de casos com determinada idade</returns>
        public void ConsultarIdade(int age)
        {
            int count = 0;

            for (int i = 0; i < numDoente; i++)
                if (doentes[i].Idade == age)
                    count++;

            Console.WriteLine("Com idade " + age + " existem " + count + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Verifica qual e imprime o numero de casos nas varias profissoes
        /// </summary>
        public void ConsultarProfissao()
        {
            int countA = 0;
            int countB = 0;
            int countC = 0;
            int countD = 0;
            int countE = 0;

            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i].Ativo == true && (int)doentes[i].Profi == 0)
                    countA++;

                if (doentes[i].Ativo == true && (int)doentes[i].Profi == 1)
                    countB++;

                if (doentes[i].Ativo == true && (int)doentes[i].Profi == 2)
                    countC++;

                if (doentes[i].Ativo == true && (int)doentes[i].Profi == 3)
                    countD++;

                if (doentes[i].Ativo == true && (int)doentes[i].Profi == 4)
                    countE++;
            }

            Console.WriteLine("Professores      -> " + countA + " casos!");
            Console.WriteLine("Funcionarios     -> " + countB + " casos!");
            Console.WriteLine("Alunos           -> " + countC + " casos!");
            Console.WriteLine("Desempregado     -> " + countD + " casos!");
            Console.WriteLine("Outro            -> " + countE + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Desativa um infetado (fica curado)
        /// </summary>
        /// <param int="id">ID do doente</param>
        public void DesativarInfetado(int id)
        {
            for(int i = 0; i < numDoente; i++)
            {
                if(doentes[i].Id == id)
                    doentes[i].Ativo = false;
            }
            
        }

        /// <summary>
        /// Imprime o numero de infetados de determinado sexo
        /// </summary>
        public void ConsultarSexo()
        {
            int countA = 0;
            int countB = 0;
            int countC = 0;

            for (int i = 0; i < numDoente; i++)
            {
                if (doentes[i].Ativo == true && (int)doentes[i].Sex == 0)
                    countA++;

                if (doentes[i].Ativo == true && (int)doentes[i].Sex == 1)
                    countB++;

                if (doentes[i].Ativo == true && (int)doentes[i].Sex == 2)
                    countC++;
            }

            Console.WriteLine("Masculino        -> " + countA + " casos!");
            Console.WriteLine("Feminino         -> " + countB + " casos!");
            Console.WriteLine("Outro            -> " + countC + " casos!");
            Console.WriteLine();
        }

        /// <summary>
        /// Procedimento que mostra a ficha de um determinado infetado através do id vindo do exterior
        /// </summary>
        /// <param int="i">Id</param>
        public void ShowFicha(int i)
        {
            Console.WriteLine("Ficha do id " + i + " ...");
            Console.WriteLine("Doente           : " + doentes[i].Nome);
            Console.WriteLine("Idade            : " + doentes[i].Idade);
            Console.WriteLine("ID               : " + doentes[i].Id);
            Console.WriteLine("Região           : " + doentes[i].Regiao);
            Console.WriteLine("Nasceu em        : " + doentes[i].DataNasc);
            Console.WriteLine("Sexo             : " + doentes[i].Sex);
            Console.WriteLine("Estado Civil     : " + doentes[i].Profi);
            Console.WriteLine("Infetado com     : " + doentes[i].AddInfecao.Tipo + " concretamente " + doentes[i].AddInfecao.Nome);
            Console.WriteLine("Ainda infetado   : " + doentes[i].Ativo);
            Console.WriteLine();
        }

        #endregion

        #region Override

        public override string ToString()
        {
            for (int i = 0; i < numDoente; i++)
            {
                Console.WriteLine("Doente           : " + doentes[i].Nome);
                Console.WriteLine("Idade            : " + doentes[i].Idade);
                Console.WriteLine("ID               : " + doentes[i].Id);
                Console.WriteLine("Região           : " + doentes[i].Regiao);
                Console.WriteLine("Nasceu em        : " + doentes[i].DataNasc);
                Console.WriteLine("Sexo             : " + doentes[i].Sex);
                Console.WriteLine("Estado Civil     : " + doentes[i].Profi);
                Console.WriteLine("Infetado com     : " + doentes[i].AddInfecao.Tipo + " concretamente " + doentes[i].AddInfecao.Nome);
                Console.WriteLine("Ainda infetado   : " + doentes[i].Ativo);
                Console.WriteLine();
            }

            Console.WriteLine("Casos Infetados: " + ContaCasos());
            Console.WriteLine();

            return "";
        }

        #endregion
    }
}
































