﻿using System;

/// <summary>
/// Trabalho Prático I - LPII
/// Autores :   Vladyslav, João
/// Data    :   20-04-2020
/// </summary>

namespace TrabalhoLP
{
    class Program
    {
        static void Main(string[] args)
        {
            // Criar as infeções
            Infecao inf1 = new Infecao("Virus", "Covid-19");
            Infecao inf2 = new Infecao("Bacteria", "Salmonela");
            Infecao inf3 = new Infecao("Cancro", "Cancro de Pulmão");
            Infecao inf4 = new Infecao("Vírus", "Gripe A");

            // Criar os doentes com os respetivos dados
            Doentes d1 = new Doentes(inf1, 20, "Vlad", 0, DateTime.Today, 0, 0);
            Doentes d2 = new Doentes(inf2, 23, "Francisco", 1, DateTime.Today, 0, 1);
            Doentes d3 = new Doentes(inf3, 20, "Joao", 2, DateTime.Today, 2, 2);
            Doentes d4 = new Doentes(inf4, 69, "Fiona", 0, DateTime.Today, 1, 3);

            // Criar um hospital
            Hospital hos = new Hospital();

            // Associar os doentes ao hospital
            hos.InsereDoente(d1);
            hos.InsereDoente(d2);
            hos.InsereDoente(d3);
            hos.InsereDoente(d4);

            // Obter as fichas de todos os infetados ou ex infetados & O número total de casos infetados
            hos.ToString();

            // Obter a contabilização de casos infetados por região
            hos.ConsultarRegiao();

            // Obter a contabilização de casos infetados por sexo
            hos.ConsultarSexo();

            // Obter a contabilização de casos infetados com certa idade
            hos.ConsultarIdade(20);

            // Obter a contabilização de casos infetados por profissão
            hos.ConsultarProfissao();

            // Desativar determinado infetado inserindo o seu id
            hos.DesativarInfetado(2);

            // Obter as fichas de todos os infetados ou ex infetados & O número total de casos infetados -> ATUALIZADOS!
            hos.ToString();

            // Obter a ficha de um determinado doente através do id
            hos.ShowFicha(0);
        }
    }
}
